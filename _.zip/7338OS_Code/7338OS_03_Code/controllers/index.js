module.exports = function(req, res, next) {	
	res.render("list", { app: "" });
}