# Running the example
1. Install NodeJS
2. Navigate to the folder via the console
3. Run `node car.js`