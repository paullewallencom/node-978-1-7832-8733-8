YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "A"
    ],
    "modules": [],
    "allModules": []
} };
});