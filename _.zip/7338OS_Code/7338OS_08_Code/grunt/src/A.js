/**
* This is the description for my class.
*
* @class A
*/
var A = {
	/**
	* My method description.  Like other pieces of your comment blocks, 
	* this can span multiple lines.
	*
	* @method method
	*/
	method: function() {

	}
};